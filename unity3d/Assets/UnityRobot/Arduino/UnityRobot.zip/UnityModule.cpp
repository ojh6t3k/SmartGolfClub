//******************************************************************************
//* Includes
//******************************************************************************
#include "UnityRobot.h"
#include "UnityModule.h"


//******************************************************************************
//* Constructors
//******************************************************************************

UnityModule::UnityModule(int id, boolean outputOnly)
{
	_id = (byte)id;
	_outputOnly = outputOnly;
	_enableFlush = true;
	nextModule = 0;
	_externalAction = 0;
}

//******************************************************************************
//* Public Methods
//******************************************************************************
void UnityModule::setup()
{
	_updated = false;
	OnSetup();
}

void UnityModule::start()
{
	_updated = false;
	_enableFlush = true;
	OnStart();
}

void UnityModule::stop()
{
	_updated = false;
	OnStop();
}

void UnityModule::process()
{
	OnProcess();
}

boolean UnityModule::update(byte id)
{
	if(_id == id)
	{
		OnUpdate();
		
		if(_outputOnly == false)
			UnityRobot.pop(&_enableFlush);

		_updated = true;
		return true;
	}

	return false;
}

void UnityModule::action()
{
	if(_updated == true)
	{
		OnAction();
		if(_externalAction != 0)
			(*_externalAction)(_id);
		_updated = false;
	}
}

void UnityModule::flush()
{
	if(_outputOnly == false)
	{
		if(_enableFlush == true)
		{
			UnityRobot.select(_id);
			OnFlush();
			UnityRobot.flush();
		}
	}
}

void UnityModule::attachAction(callbackAction externalAction)
{
	_externalAction = externalAction;
}

void UnityModule::dettachAction()
{
	_externalAction = 0;
}

