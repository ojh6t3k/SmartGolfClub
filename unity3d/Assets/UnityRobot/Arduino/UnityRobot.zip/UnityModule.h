#ifndef UnityModule_h
#define UnityModule_h


extern "C"
{
    typedef void (*callbackAction)(byte);	
}

class UnityModule
{
public:
	UnityModule* nextModule;

	UnityModule(int id, boolean outputOnly);

	void setup();
	void start();
	void stop();
	void process();
	boolean update(byte id);
	void action();
	void flush();
	void attachAction(callbackAction externalAction);
	void dettachAction();

protected:
	virtual void OnSetup() {}
	virtual void OnStart() {}
	virtual void OnStop() {}
	virtual void OnProcess() {}
	virtual void OnUpdate() {}
	virtual void OnAction() {}
	virtual void OnFlush() {}

	boolean _outputOnly;

private:
	byte _id;
	byte _enableFlush;	
	boolean _updated;

	callbackAction _externalAction;
};

#endif

