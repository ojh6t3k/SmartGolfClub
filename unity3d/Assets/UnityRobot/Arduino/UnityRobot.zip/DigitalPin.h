#ifndef DigitalPin_h
#define DigitalPin_h

#include "UnityModule.h"


class DigitalPin : UnityModule
{
public:
	DigitalPin(int id, int pin);	

protected:
	void OnSetup();
	void OnStart();
	void OnStop();
	void OnProcess();
	void OnUpdate();
	void OnAction();
	void OnFlush();

private:
    int _pin;
	byte _mode;	
	byte _state;

	void setMode();
};

#endif

