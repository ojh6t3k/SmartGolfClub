[Informations]
Guide Link(https://sites.google.com/site/unityrobotguide/)
All right reserved Idealink(http://www.idealink.kr)

[Release Note]
*v1.0.0b4 (November/14/2014)
<Arduino>
 -[Fix]DigitalPin - mode changing
<Unity3D>
 -[Fix]DigitalPin - mode changing
<PlayMakerNGUI>
 -[Add]UnityPackage(First released)