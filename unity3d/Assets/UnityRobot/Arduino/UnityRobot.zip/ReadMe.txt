[Informations]
Guide Link(https://sites.google.com/site/unityrobotguide/)
All right reserved Idealink(http://www.idealink.kr)

[Release Note]
*v1.0.0b6 (November/28/2014)
<Arduino>
 -
<Unity3D>
 -[Fix]Kepp changed propertis of UnityRobot in prefab
 -[Add]AnalogPinFilter
<PlayMakerNGUI>
 -[Add]UnityRobotPortNamesUIPopup
 -[Add]Example: Flex_BedingObject
 -[Add]Example: Flex_BounceBall
 -[Add]Example: Photo_LightControl
 -[Add]Example: UnityRobotGUI